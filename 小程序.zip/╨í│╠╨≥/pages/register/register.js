var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var that;

// 获取全局应用程序实例对象
var app = getApp();
    
// 创建页面实例对象
Page({
  data: {
    userInfo: {},
    showView: false,
    loading: true,
    array1: ['求真1', '求真2', '问源1', '问源2', '慕贤1', '慕贤2', '慕贤3', '弘毅1', '弘毅2', '精诚1', '精诚2', '致远1', '致远2', '尚雅1', '尚雅2', '思睿1', '思睿2', '惟学1', '明德2', '明德3'],
    array2: ['求真', '问源', '慕贤', '弘毅', '精诚', '致远', '尚雅', '思睿', '惟学', '明德'],
    index: 0,
  },
  onLoad: function (options) {
    that = this;
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      console.log(userInfo)
      //更新数据
      that.setData({
        userInfo: userInfo
      })
    })
    showView: (options.showView == "true" ? true : false)  
  },

  radioChange: function () {
    that = this;
    that.setData({
      showView: (!that.data.showView)
    })
  },  

  pickerSelected1: function (e) {
    //改变index值，通过setData()方法重绘界面
    this.setData({
      index: e.detail.value
    });
  }, 

  pickerSelected2: function (e) {
    //改变index值，通过setData()方法重绘界面
    this.setData({
      index: e.detail.value
    });
  }, 

  tap_cancel: function (e) {
    wx.navigateBack({

    })
  },

  formSubmit: function (event) {
    Bmob.User.logOut();
    that.setData({
      loading: false,
      tips: "用户注册中，请稍后！"
    })
    var accouttype = event.detail.value.type;
    var accoutName = event.detail.value.accoutName;
    var realname = event.detail.value.realname;
    var dormname = event.detail.value.picker1;
    var dormnameadmin = event.detail.value.picker2;
    var dormnum = event.detail.value.dormnum;
    var bednum = event.detail.value.bednum;
    var accoutPswd = event.detail.value.accoutPswd;
    var accoutPswd1 = event.detail.value.accoutPswd1;

    var User = Bmob.Object.extend("_User");
    var query = new Bmob.Query(User);
    var user = new Bmob.User();
    query.equalTo("username", accoutName);
    query.first({
      success: function (object) {
        user = object;// 查询成功
        if (user == undefined) {
          common.showTip("该学号或工号不存在！", "loading");
        }
        else {
          var dbtype = user.get("type");
          var dbrealname = user.get("userRealName");
          var dbdormname = user.get("dormName");
          var dbdormnameadmin = user.get("dormNameAdmin");
          var dbdormnum = user.get("dormNum");
          var dbbednum = user.get("bedNo");
          if (user.get("registered") == true) common.showTip("该用户已注册！", "loading");
          else if (accouttype == 1) {
            if (accoutPswd != accoutPswd1 || accoutPswd == "") common.showTip("密码填写有误", "loading");
            else {
              if (accoutName != "" && accouttype==dbtype && realname==dbrealname && dormname==dbdormname && dormnum==dbdormnum && bednum==dbbednum) {
                Bmob.User.logIn(accoutName, accoutName, {
                  success: function (user) {
                    wx.getStorage({
                      key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
                      success: function (res) {
                        var Data = JSON.parse(res.data);
                        var currentUser = Bmob.User.current();
                        console.log(currentUser);
                        currentUser.set("password", accoutPswd);
                        currentUser.set("registered", true);
                        currentUser.set("userPic", that.data.userInfo.avatarUrl);
                        currentUser.save();
                        that.setData({
                          loading: true,
                        })
                        common.showTip("注册成功,正在跳转", "success", function () {
                          wx.reLaunch({
                            url: '../indexuser/indexuser'
                          })
                        });
                      }
                    })
                  },
                  error: function (user, error) {
                    // The login failed. Check error to see why.
                    console.log(error)
                  }
                });

                // user.signUp(null, {
                //   success: function (res) {
                //     that.setData({
                //       loading: true,
                //     })
                //     common.showTip("注册成功,正在跳转", "success", function () {
                //       wx.redirectTo({
                //         url: '../login/login'
                //       })
                //     });

                //     console.log(res)
                //     // wx.getStorage({
                //     //     key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
                //     //     success: function(res) {
                //     //         var Data =JSON.parse(res.data) ;
                //     //         if(Data.code=="202"){
                //     //             common.showTip("该用户名已经存在！","loading");
                //     //         }
                //     //         else{
                //     //             common.showTip("注册成功请登录","success",function(){
                //     //                 wx.redirectTo({
                //     //                  url: '../login/login'
                //     //                 })
                //     //             });
                //     //         }
                //     //     }
                //     // })
                //   },
                //   error: function (userData, error) {
                //     that.setData({
                //       loading: true,
                //     })
                //     console.log(userData)
                //     console.log("userData")
                //     console.log(error)
                //   },
                //   complete: function (userData) {
                //     that.setData({
                //       loading: true,
                //     })
                //   }
                // });
              }
              else {
                console.log("寝室信息有误");
                common.showTip("寝室信息有误", "loading");
              }
            }
          }
          else if (accouttype == 2) {
            if (accoutPswd != accoutPswd1 || accoutPswd == "") common.showTip("密码填写有误", "loading");
            else {
              if (accoutName != "" && accouttype == dbtype && realname == dbrealname && dormnameadmin == dbdormnameadmin) {
                Bmob.User.logIn(accoutName, accoutName, {
                  success: function (user) {
                    wx.getStorage({
                      key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
                      success: function (res) {
                        var Data = JSON.parse(res.data);
                        var currentUser = Bmob.User.current();
                        console.log(currentUser);
                        currentUser.set("password", accoutPswd);
                        currentUser.set("registered", true);
                        currentUser.set("userPic", that.data.userInfo.avatarUrl);
                        currentUser.save();
                        that.setData({
                          loading: true,
                        })
                        common.showTip("注册成功,正在跳转", "success", function () {
                          wx.redirectTo({
                            url: '../indexadmin/indexadmin'
                          })
                        });
                      }
                    })
                  },
                  error: function (user, error) {
                    // The login failed. Check error to see why.
                    console.log(error)
                  }
                });
              }
              else {
                console.log("寝室信息有误");
                common.showTip("寝室信息有误", "loading");
              }
            }
          }
        }
      },
      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
  }

//   /**
//    * 生命周期函数--监听页面加载
//    */
//   onLoad () {

//   },

//   /**
//    * 生命周期函数--监听页面初次渲染完成
//    */
//   onReady () {

//   },

//   /**
//    * 生命周期函数--监听页面显示
//    */
//   onShow () {

//   },

//   /**
//    * 生命周期函数--监听页面隐藏
//    */
//   onHide () {

//   },

//   /**
//    * 生命周期函数--监听页面卸载
//    */
//   onUnload () {

//   },

//   /**
//    * 页面相关事件处理函数--监听用户下拉动作
//    */
//   onPullDownRefresh () {
    
//   },
  
// })


})