var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
// var User = Bmob.Object.extend("user");
// var query = new Bmob.Query(User);


Page({
  onLoad: function () {
  },
  data: {
    
  },
  /**
     * 生命周期函数--监听页面加载
     */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  radioChange:function(e) {
  //   console.log(e.detail.value);
  },

  tap_register: function (e) {
    wx.navigateTo({
      url: '../register/register',
    })
  },

  tap_cancel: function (e) {
    wx.navigateBack({
      
    })
  },

  formSubmit: function (event) {
    Bmob.User.logIn(event.detail.value.id, event.detail.value.passwd,{
      success: function (user) {
        // var currentUser = Bmob.User.current();
        if (user.get("registered")!=true) {
          common.showTip("对不起,您输入的用户不存在或密码错误", "loading");
          Bmob.User.logOut();
        }
        else if (user.get("type") != event.detail.value.type) {
          common.showTip("对不起,您输入的用户不存在或密码错误", "loading");
          Bmob.User.logOut();
        }
        else {
          wx.getStorage({
            key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
            success: function (res) {
              var Data = JSON.parse(res.data);
              common.showTip("登录成功,正在跳转", "success", function () {
                if (event.detail.value.type == 1) {
                  wx.reLaunch({
                    url: '../indexuser/indexuser'
                  })
                }
                else if (event.detail.value.type == 2) {
                  wx.reLaunch({
                    url: '../indexadmin/indexadmin'
                  })
                }
              });
            }
          })
        }        
      },
      error: function (user, error) {
        // The login failed. Check error to see why.
        console.log(error)
        common.showTip("对不起,您输入的用户不存在或密码错误", "loading");
      }
    });

    
  }

  // formSubmit: function (event) {
  //   query.equalTo("id", Number(event.detail.value.id));
  //   // 查询所有数据
  //   query.first({
  //     success: function (object) {
  //       if (!object) common.showTip("对不起,您输入的用户不存在或密码错误", "loading");
  //       else if (object.get('password') != event.detail.value.passwd || object.get('type') != event.detail.value.type) {
  //         console.log(event.detail.value.type);
  //           common.showTip("对不起,您输入的用户不存在或密码错误", "loading");
  //       }
  //       else {
  //         common.showTip("登录成功,正在跳转", "success", function () {
  //             wx.reLaunch({
  //               url: '../indexuser/indexuser'
  //             })
  //         });
  //       }
  //     },
  //     error: function (error) {
  //       common.showTip("对不起,您输入的用户不存在或密码错误", "loading");
  //     }
  //   });
  // }

})