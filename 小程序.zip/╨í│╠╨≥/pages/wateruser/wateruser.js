var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
// 获取全局应用程序实例对象
var app = getApp();
var that;

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "barreledwateruser",
  /**
   * 页面的初始数据
   */

  data: {
    user: {},
    array1: ['求真1', '求真2', '问源1', '问源2', '慕贤1', '慕贤2', '慕贤3', '弘毅1', '弘毅2', '精诚1', '精诚2', '致远1', '致远2', '尚雅1', '尚雅2', '思睿1', '思睿2', '惟学1', '明德2', '明德3'],
    index: 0,
    money: 0,
    loading: true,
    openId: '',
    dataInfo: [],
    PayResult: ''
  },

  pickerSelected1: function (e) {
    //改变index值，通过setData()方法重绘界面
    that.setData({
      index: e.detail.value
    });
  }, 

  tap_cancel: function (e) {
    wx.navigateBack({

    })
  },

  inputEvent: function (e) {
    that = this;
    if (e.detail.value > 0 && e.detail.value < 6) {
      that.setData({
        money: e.detail.value * 0.01
      })
    }
    else {
      that.setData({
        money: 0
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    console.log(typeof 1.5)
    that = this;
    // 页面初始化 options为页面跳转所带来的参数
    that.setData({
      user: Bmob.User.current(),
      index: that.data.array1.indexOf(Bmob.User.current().get("dormName"))
    })

    //获取open id，请在官网填写微信小程序key
    wx.login({
      success: function (res) {
        if (res.code) {
          //发起网络请求
          console.log(res.code)

          Bmob.User.requestOpenId(res.code, {
            success: function (result) {

              that.setData({
                loading: true,
                openId: result.openid
              })
              console.log(result)
            },
            error: function (error) {
              // Show the error message somewhere
              console.log("Error: " + error.code + " " + error.message);
            }
          });
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
          common.showTip('获取用户登录态失败！', 'loading');
        }
      }
    });

  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },

  formSubmit: function (event) {
    var dormname = event.detail.value.picker1;
    var dormnum = event.detail.value.dormnum;
    var quantity = event.detail.value.quantity;
    if (quantity > 0 && quantity < 6 && parseInt(quantity) == quantity && dormnum > 100 && dormnum < 800) {
      var openId = this.data.openId;

      if (!openId) {
        console.log('未获取到openId请刷新重试');
      }

      //传参数金额，名称，描述,openid
      Bmob.Pay.wechatPay(that.data.money, '桶装水', '桶装水', openId).then(function (resp) {
        console.log('resp');
        console.log(resp);

        that.setData({
          loading: true,
          dataInfo: resp
        })

        //服务端返回成功
        var timeStamp = resp.timestamp,
          nonceStr = resp.noncestr,
          packages = resp.package,
          orderId = resp.out_trade_no,//订单号，如需保存请建表保存。
          sign = resp.sign;

        //打印订单号
        console.log(orderId);

        //发起支付
        wx.requestPayment({
          'timeStamp': timeStamp,
          'nonceStr': nonceStr,
          'package': packages,
          'signType': 'MD5',
          'paySign': sign,
          'success': function (res) {
            //付款成功,这里可以写你的业务代码
            var BoardOrder = Bmob.Object.extend("BoardOrder");
            var boardOrder = new BoardOrder();
            var currentUser = Bmob.User.current();
            // 添加数据，第一个入口参数是Json数据
            boardOrder.save({
              username: currentUser.get("username"),
              state:false,
              dormName: dormname,
              dormNum: dormnum,
              amount: Number(quantity),
              orderId: orderId,
            }, {
                success: function (result) {
                  // 添加成功
                  console.log("订水记录创建成功, objectId:" + result.id);
                  wx.redirectTo({
                    url: '../successful/successful',
                  })
                },
                error: function (result, error) {
                  // 添加失败
                  console.log('创建订水记录失败');
                }
              });

            console.log(res);
          },
          'fail': function (res) {
            //付款失败
            console.log('付款失败');
            console.log(res);
            // wx.redirectTo({
            //   url: '../payfailed/payfailed',
            // })
          }
        })

      }, function (err) {
        console.log('服务端返回失败');
        common.showTip(err.message, 'loading', {}, 6000);
        console.log(err);
      });
    }
    else {
      console.log("信息填写有误")
      common.showTip("订单信息填写有误", "loading");
    }
  },
})