var Bmob = require('../../utils/bmob.js');
// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "indexuser",
  /**
   * 页面的初始数据
   */

  data: {
    open: false,
    user: {},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad () {
    this.setData({
      user: Bmob.User.current(),
    }) 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh () {
    
  },


  //以下为自定义点击事件

  tap_ch: function (e) {
    if (this.data.open) {
      this.setData({
        open: false
      });
    } else {
      this.setData({
        open: true
      });
    }
  },

  tap_modify:function(e){
    wx.navigateTo({
      url: 'modifyuser/modifyuser'
    })
  },
  
  tap_historywater:function(e){
    wx.navigateTo({
      url: '../historywater/historywater'
    })
  },

  tap_historyele: function (e) {
    wx.navigateTo({
      url: '../historyele/historyele'
    })
  },

  tap_feedback:function(e){
    wx.navigateTo({
      url: '../feedback/feedback'
    })
  },
  
  tap_about:function(e){
    wx.navigateTo({
      url: '../about/about'
    })
  },
  
  tap_exit:function(e){
    Bmob.User.logOut();
    wx.reLaunch({
      url: '../indexnotlogin/indexnotlogin'
    })
  },
  
})