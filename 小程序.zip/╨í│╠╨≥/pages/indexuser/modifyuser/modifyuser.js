var Bmob = require('../../../utils/bmob.js');
var common = require('../../../utils/common.js');

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "modifyuser",
  /**
   * 页面的初始数据
   */

  data: {
    user: {},
    array1: ['求真1', '求真2', '问源1', '问源2', '慕贤1', '慕贤2', '慕贤3', '弘毅1', '弘毅2', '精诚1', '精诚2', '致远1', '致远2', '尚雅1', '尚雅2', '思睿1', '思睿2', '惟学1', '明德2', '明德3'],
    index: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad () {
    this.setData({
      user: Bmob.User.current(),
      index: this.data.array1.indexOf(Bmob.User.current().get("dormName"))
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh () {
    
  },


  //以下为自定义点击事件
  
  pickerSelected1: function (e) {
    //改变index值，通过setData()方法重绘界面
    this.setData({
      index: e.detail.value
    });
  }, 

  tap_cancel:function(e){
    wx.navigateBack({

    })
  },
  
  formSubmit: function (event) {
    var dormname = event.detail.value.picker1;
    var dormnum = event.detail.value.dormnum;
    var bednum = event.detail.value.bednum;
    var accoutPswd = event.detail.value.accoutPswd;
    var accoutPswd1 = event.detail.value.accoutPswd1;

    // if (dormnum > 100 && dormnum < 800 && bednum >= 1 && bednum <= 4 && accoutPswd == accoutPswd1) {
    if (accoutPswd == accoutPswd1 && accoutPswd != "") {
      wx.getStorage({
        key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
        success: function (res) {
          var Data = JSON.parse(res.data);
          var currentUser = Bmob.User.current();
          // if (accoutPswd != "") {
            currentUser.set("password", accoutPswd);
          // }
          // currentUser.set("dormName", dormname);
          // currentUser.set("dormNum", dormnum);
          // currentUser.set("bedNo", Number(bednum));
          console.log(currentUser);
          currentUser.save();
          common.showTip("密码修改成功！", "success", function () {
            wx.reLaunch({
              url: '../indexuser'
            })
          });
        }
      });
    }
    else {
      console.log("密码填写有误")
      common.showTip("密码填写有误", "loading");
    }
  }
})

