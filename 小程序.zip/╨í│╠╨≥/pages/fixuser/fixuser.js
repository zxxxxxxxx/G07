var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
// 获取全局应用程序实例对象
var app = getApp();
var that;

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "fixuser",
  /**
   * 页面的初始数据
   */

  data: {
    user: {},
    array1: ['慕贤1', '慕贤2', '慕贤3', '弘毅1', '弘毅2', '精诚1', '精诚2', '致远1', '致远2', '尚雅1', '尚雅2', '思睿1', '思睿2', '求真1', '求真2', '惟学1', '明德2', '明德3', '问源1', '问源2'],
    index: 0,
  },

  pickerSelected1: function (e) {
    //改变index值，通过setData()方法重绘界面
    this.setData({
      index: e.detail.value
    });
  }, 

  tap_cancel: function (e) {
    wx.navigateBack({

    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad () {
    that = this;
    // 页面初始化 options为页面跳转所带来的参数
    that.setData({
      user: Bmob.User.current(),
      index: that.data.array1.indexOf(Bmob.User.current().get("dormName"))
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh () {
    
  },

  formSubmit: function (event) {
    var dormname = event.detail.value.picker1;
    var dormnum = event.detail.value.dormnum;
    // var bednum = event.detail.value.bednum;
    var textarea = event.detail.value.textarea;
    // if (dormnum > 100 && dormnum < 800 && bednum >= 1 && bednum <= 4 && textarea !="") {
    if (dormnum > 100 && dormnum < 800 && textarea != "") {
      var FixOrder = Bmob.Object.extend("FixOrder");
      var fixOrder = new FixOrder();
      var currentUser = Bmob.User.current();
      // 添加数据，第一个入口参数是Json数据
      fixOrder.save({
        username: currentUser.get("username"),
        state:false,
        dormName: dormname,
        dormNum: dormnum,
        // bedNo: Number(bednum),
        content: textarea,
      }, {
          success: function (result) {
            // 添加成功
            console.log("报修记录创建成功, objectId:" + result.id);
            wx.redirectTo({
              url: '../successful/successful',
            })
          },
          error: function (result, error) {
            // 添加失败
            console.log('创建报修记录失败');
          }
        });
    }
    else {
      console.log("信息填写有误")
      common.showTip("报修信息填写有误", "loading");
    }
  },
})

