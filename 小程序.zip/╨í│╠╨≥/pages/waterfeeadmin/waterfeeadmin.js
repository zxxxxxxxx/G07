//index.js
//获取应用实例
var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
var that;
Page({

  data: {
    user: {},
    writeBoardOrder: false,
    loading: false,
    windowHeight: 0,
    windowWidth: 0,
    limit: 10,
    boardOrderList: [],
    modifyBoardOrders: false
  },
  onReady: function (e) {

  },
  onLoad: function () {
    that = this;
    that.setData({
      user: Bmob.User.current()
    })
  },
  noneWindows: function () {
    that.setData({
      writeBoardOrder: "",
      modifyBoardOrders: ""
    })
  },
  onShow: function () {

    getList(this);

    wx.getSystemInfo({
      success: (res) => {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },
  pullUpLoad: function (e) {
    var limit = that.data.limit + 2
    this.setData({
      limit: limit
    })
    this.onShow()
  },
  toAddBoardOrder: function () {
    that.setData({
      writeBoardOrder: true
    })
  },
  addBoardOrder: function (event) {
    var dormname = event.detail.value.dormname;
    var dormnum = event.detail.value.dormnum;
    var money = event.detail.value.money;
    console.log("event", event)
    if (!dormname || !dormnum) {
      common.showTip("寝室信息不能为空", "loading");
    }
    else if (!money) {
      common.showTip("金额不能为空", "loading");
    }
    else if (dormname < 1 || dormname > 3 || dormnum <= 100 || dormnum >= 800) {
      common.showTip("寝室信息有误", "loading");
    }
    else if ( money > 2000||money<=0) {
      common.showTip("金额填写有误", "loading");
    }
    else {
      that.setData({
        loading: true
      })
      var currentUser = Bmob.User.current();

      var User = Bmob.Object.extend("_User");
      var UserModel = new User();

      //增加订水单
      var BoardOrder = Bmob.Object.extend("WaterFee");
      var boardOrder = new BoardOrder();
      boardOrder.set("username", currentUser.get("username"));
      boardOrder.set("dormName", currentUser.get("dormNameAdmin") + dormname);
      boardOrder.set("dormNum", dormnum);
      boardOrder.set("money", Number(money));
      if (currentUser) {
        UserModel.id = currentUser.id;
        boardOrder.set("own", UserModel);
      }
      //添加数据，第一个入口参数是null
      boardOrder.save(null, {
        success: function (result) {
          // 添加成功，返回成功之后的objectId（注意：返回的属性名字是id，不是objectId），你还可以在Bmob的Web管理后台看到对应的数据
          common.showTip('添加水费单成功');
          that.setData({
            writeBoardOrder: false,
            loading: false
          })
          that.onShow()
        },
        error: function (result, error) {
          // 添加失败
          common.showTip('添加水费单失败，请重新发布', 'loading');

        }
      });
    }

  },
  closeLayer: function () {
    that.setData({
      writeboardOrder: false
    })
  },
  deleteBoardOrder: function (event) {
    var that = this;
    var objectId = event.target.dataset.id;
    wx.showModal({
      title: '操作提示',
      content: '确定要删除该水费单？',
      success: function (res) {
        if (res.confirm) {
          //删除订水单
          var BoardOrder = Bmob.Object.extend("WaterFee");

          //创建查询对象，入口参数是对象类的实例
          var query = new Bmob.Query(BoardOrder);
          query.get(objectId, {
            success: function (object) {
              // The object was retrieved successfully.
              object.destroy({
                success: function (deleteObject) {
                  console.log('删除水费单成功');
                  common.showTip('删除水费单成功');
                  getList(that)
                },
                error: function (object, error) {
                  console.log('删除水费单失败');
                  common.showTip('删除水费单失败', 'loading');
                }
              });
            },
            error: function (object, error) {
              console.log("query object fail");
            }
          });
        }
      }
    })
  },
  toModifyBoardOrder: function (event) {
    var nowDormName = event.target.dataset.dormname.substring(2);
    var nowDormNum = event.target.dataset.dormnum;
    var nowMoney = event.target.dataset.money;
    var nowState = event.target.dataset.state == true ? true : false;
    var nowId = event.target.dataset.id;
    that.setData({
      modifyBoardOrders: true,
      nowDormName: nowDormName,
      nowDormNum: nowDormNum,
      nowMoney: nowMoney,
      nowState: nowState,
      nowId: nowId
    })
  },
  modifyBoardOrder: function (e) {
    var t = this;
    modify(t, e)
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    getList(this);
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    getList(this);
  },
  inputTyping: function (e) {
    //搜索数据
    getList(this, e.detail.value);
    this.setData({
      inputVal: e.detail.value
    });
  },
  closeAddLayer: function () {
    that.setData({
      modifyBoardOrders: false
    })
  }

})


/*
* 获取数据
*/
function getList(t, k) {
  that = t;
  var currentUser = Bmob.User.current();
  var BoardOrder = Bmob.Object.extend("WaterFee");
  var query = new Bmob.Query(BoardOrder);
  var query1 = new Bmob.Query(BoardOrder);
  var query2 = new Bmob.Query(BoardOrder);
  //会员模糊查询
  if (k) {
    if (k == "已交") k = true; else if (k == "未交") k = false;
    query.equalTo("dormName", { "$regex": "" + k + ".*" });
    query1.equalTo("dormNum", { "$regex": "" + k + ".*" });
    query2.equalTo("state", k);
  }

  //普通会员匹配查询
  // query.equalTo("dorm", k);
  var mainQuery = Bmob.Query.or(query, query1, query2);
  mainQuery.startsWith("dormName", currentUser.get("dormNameAdmin"));
  mainQuery.descending('updatedAt');
  mainQuery.include("own")
  // 查询所有数据
  mainQuery.limit(that.data.limit);


  mainQuery.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        boardOrderList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}

function modify(t, e) {
  var that = t;
  //修改订水单
  var modyDormName = e.detail.value.dormname;
  var modyDormNum = e.detail.value.dormnum;
  var modyMoney = e.detail.value.money;
  var modyState = e.detail.value.state;
  var objectId = e.detail.value.money;
  var thatDormName = that.data.nowDormName;
  var thatDormNum = that.data.nowDormNum;
  var thatMoney = that.data.nowMoney;
  var thatState = that.data.nowState;
  if ((modyDormName != thatDormName || modyDormNum != thatDormNum || modyMoney != thatMoney || modyState != thatState)) {
    if (modyDormName == "" || modyDormNum == "") {
      common.showTip('寝室信息不能为空', 'loading');
    }
    else if (modyMoney == "") {
      common.showTip("金额不能为空", "loading");
    }
    else if (modyDormName < 1 || modyDormName > 3 || modyDormNum <= 100 || modyDormNum >= 800) {
      common.showTip("寝室信息有误", "loading");
    }
    else if ( modyMoney >2000||modyMoney<=0) {
      common.showTip("金额填写有误", "loading");
    }
    else {
      console.log(modyMoney)
      var BoardOrder = Bmob.Object.extend("WaterFee");
      var query = new Bmob.Query(BoardOrder);
      var currentUser = Bmob.User.current();
      // 这个 id 是要修改条目的 id，你在生成这个存储并成功时可以获取到，请看前面的文档
      query.get(that.data.nowId, {
        success: function (result) {
          // 回调中可以取得这个 GameScore 对象的一个实例，然后就可以修改它了
          if (modyState=="true") result.set('state', true);
          else if (modyState == "false") result.set('state', false);
          result.set("dormName", currentUser.get("dormNameAdmin") + modyDormName);
          result.set('dormNum', modyDormNum);
          result.set('money', Number(modyMoney));
          result.save();
          common.showTip('订水单修改成功', 'success', function () {
            that.onShow();
            that.setData({
              modifyBoardOrders: false
            })
          });

          // The object was retrieved successfully.
        },
        error: function (object, error) {

        }
      });
    }
  }
  else if (modyDormName == "" || modyDormNum == "" || modyMoney == "") {
    common.showTip('寝室信息或数量不能为空', 'loading');
  }
  else {
    that.setData({
      modifyBoardOrders: false
    })
    common.showTip('修改成功', 'loading');
  }
}