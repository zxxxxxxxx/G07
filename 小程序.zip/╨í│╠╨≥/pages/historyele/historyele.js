//index.js
//获取应用实例
var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
var that;
Page({

  data: {
    writeNotice: false,
    loading: false,
    windowHeight: 0,
    windowWidth: 0,
    limit: 10,
    noticeList: [],
    modifyNotices: false
  },
  onReady: function (e) {

  },
  
  onLoad: function () {


    that = this;



  },
  noneWindows: function () {
    that.setData({
      writeNotice: "",
      modifyNotices: ""
    })
  },
  onShow: function () {

    getList(this);


    wx.getSystemInfo({
      success: (res) => {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },
  pullUpLoad: function (e) {
    var limit = that.data.limit + 2
    this.setData({
      limit: limit
    })
    this.onShow()
  },
  toAddNotice: function () {
    that.setData({
      writeNotice: true
    })
  },

  closeLayer: function () {
    that.setData({
      writenotice: false
    })
  },
 


  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    getList(this);
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    getList(this);
  },
  inputTyping: function (e) {
    //搜索数据
    getList(this, e.detail.value);
    this.setData({
      inputVal: e.detail.value
    });
  },
  closeAddLayer: function () {
    that.setData({
      modifyNotices: false
    })
  }

})


/*
* 获取数据
*/
function getList(t, k) {
  that = t;

  var currentUser = Bmob.User.current();
  var Dorm = Bmob.Object.extend("_User");
  


  var Notice = Bmob.Object.extend("EleFee");
  var query = new Bmob.Query(Notice);
  query.equalTo("dormName", currentUser.get("dormName"));
  query.equalTo("dormNum", currentUser.get("dormNum"));
  query.equalTo("state",true);
  if (k) {
    query.equalTo("updatedAt", k);
  
  }
  //普通会员匹配查询
  query.descending('updatedAt');
  query.limit(that.data.limit);


  query.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(currentUser);
      // 循环处理查询到的数据
    
      console.log(results);
      that.setData({
        noticeList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}

