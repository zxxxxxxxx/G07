//index.js
//获取应用实例
var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
var that;
Page({

  data: {
    loading: false,
    windowHeight: 0,
    windowWidth: 0,
    // limit: 10,
    noticeList: [],
  },
  onReady: function (e) {

  },
  
  onLoad: function () {
    that = this;
  },

  onShow: function () {

    getList(this);


    wx.getSystemInfo({
      success: (res) => {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },
  pullUpLoad: function (e) {
    // var limit = that.data.limit + 2
    // this.setData({
    //   limit: limit
    // })
    this.onShow()
  },
  deleteNotice: function (event) {

    var that = this;

    var objectId = event.target.dataset.id;
    wx.showModal({
      title: '操作提示',
      content: '确定要删除该通知？',
      success: function (res) {
        if (res.confirm) {
          //删除通知
          var Notice = Bmob.Object.extend("notice");

          //创建查询对象，入口参数是对象类的实例
          var query = new Bmob.Query(Notice);
          query.get(objectId, {
            success: function (object) {
              // The object was retrieved successfully.
              object.destroy({
                success: function (deleteObject) {
                  console.log('删除通知成功');
                  getList(that)
                },
                error: function (object, error) {
                  console.log('删除通知失败');
                }
              });
            },
            error: function (object, error) {
              console.log("query object fail");
            }
          });
        }
      }
    })
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    getList(this);
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    getList(this);
  },
  inputTyping: function (e) {
    //搜索数据
    getList(this, e.detail.value);
    this.setData({
      inputVal: e.detail.value
    });
  },

})


/*
* 获取数据
*/
function getList(t, k) {
  that = t;
  var Notice = Bmob.Object.extend("_User");
  var query = new Bmob.Query(Notice);

  //会员模糊查询
  if (!k) {
    k="1111111111";
  }

  query.equalTo("userRealName", k);
  query.find({
    success: function (results) {
      // 循环处理查询到的数据
      console.log(results);
      that.setData({
        noticeList: results
      })
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}