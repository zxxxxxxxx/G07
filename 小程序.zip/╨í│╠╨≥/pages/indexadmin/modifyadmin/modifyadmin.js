var Bmob = require('../../../utils/bmob.js');
var common = require('../../../utils/common.js');

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "modifyadmin",
  /**
   * 页面的初始数据
   */
  
  data: {
    user: {},
    array2: ['求真', '问源', '慕贤', '弘毅', '精诚', '致远', '尚雅', '思睿', '惟学', '明德'],
    index: 0,
  },

  /**
     * 生命周期函数--监听页面加载
     */
  onLoad() {
    this.setData({
      user: Bmob.User.current(),
      index: this.data.array2.indexOf(Bmob.User.current().get("dormNameAdmin"))
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },
  
  //以下为自定义点击事件

  pickerSelected2: function (e) {
    //改变index值，通过setData()方法重绘界面
    this.setData({
      index: e.detail.value
    });
  }, 

  tap_cancel: function (e) {
    wx.navigateBack({

    })
  },

  formSubmit: function (event) {
    var dormnameadmin = event.detail.value.picker2;
    var accoutPswd = event.detail.value.accoutPswd;
    var accoutPswd1 = event.detail.value.accoutPswd1;

    if (accoutPswd == accoutPswd1) {
      wx.getStorage({
        key: Bmob._getBmobPath(Bmob.User._CURRENT_USER_KEY),
        success: function (res) {
          var Data = JSON.parse(res.data);
          var currentUser = Bmob.User.current();
          if (accoutPswd != "") {
            currentUser.set("password", accoutPswd);
          }
          currentUser.set("dormNameAdmin", dormnameadmin);
          console.log(currentUser);
          currentUser.save();
          common.showTip("信息修改成功！", "success", function () {
            wx.reLaunch({
              url: '../indexadmin'
            })
          });
        }
      });
    }
    else {
      console.log("信息填写有误")
      common.showTip("信息填写有误", "loading");
    }
  }

})