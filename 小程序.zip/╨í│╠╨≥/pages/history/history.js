//index.js
//获取应用实例
var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var app = getApp();
var that;
Page({

  data: {
    // windowHeight: 0,
    // windowWidth: 0,
    limit: 10,
    historyList: [],
    loading: true,
  },
  onReady: function (e) {

  },
  onLoad: function () {
    that = this;
    getList(this);
    // wx.getSystemInfo({
    //   success: (res) => {
    //     that.setData({
    //       windowHeight: res.windowHeight,
    //       windowWidth: res.windowWidth
    //     })
    //   }
    // })
  },
  // onShow: function () {
  //   this.setData({
  //     loading: true,
  //   });
  //   // getList(this);
  //   f;
  //   console.log(that.data.historyList)
  //   console.log(that.data.historyList)
  //   // this.setData({
  //   //   loading: false
  //   // });
  // },
  // pullUpLoad: function (e) {
  //   // var limit = that.data.limit + 2
  //   // this.setData({
  //   //   limit: limit
  //   // })
  //   this.onShow()
  // },
  // bindscrolltoupper: function (e) {
  //   // var limit = that.data.limit + 2
  //   // this.setData({
  //   //   limit: limit
  //   // })
  //   getList(this);
  //   this.onShow()
  //   console.log(e)
  // },
  // bindscrolltolower: function (e) {
  //   // var limit = that.data.limit + 2
  //   // this.setData({
  //   //   limit: limit
  //   // })
  //   getList(this);
  //   this.onShow()
  //   console.log(e)
  // },
  // scroll: function (e) {
  //   console.log(e)
  // },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
    // getList(this);
    f;
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
    // getList(this);
    f;
  },
  inputTyping: function (e) {
    //搜索数据
    // getList(this, e.detail.value);
    f;
    this.setData({
      inputVal: e.detail.value
    });
  },

})

var compare = function (a,b) {
  var val1 = a.createdAt;
  var val2 = b.createdAt;
  if (val1 < val2) return 1;
  else if (val1 > val2) return -1; 
  else return 0;        
}

/*
* 获取数据
*/
function getList(t, k) {
  that = t;
  that.setData({
    historyList: [],
  });
  var dormName = Bmob.User.current().get("dormName");
  var dormNum = Bmob.User.current().get("dormNum");
  var BoardOrder = Bmob.Object.extend("BoardOrder");
  var WaterFee = Bmob.Object.extend("WaterFee");
  var EleFee = Bmob.Object.extend("EleFee");
  var FixOrder = Bmob.Object.extend("FixOrder");
  var query = new Bmob.Query(BoardOrder);
  var query1 = new Bmob.Query(WaterFee);
  var query2 = new Bmob.Query(EleFee);
  var query3 = new Bmob.Query(FixOrder);

  query.equalTo("dormName", dormName);
  query.equalTo("dormNum", dormNum);
  query1.equalTo("dormName", dormName);
  query1.equalTo("dormNum", dormNum);
  query1.equalTo("state", true);
  query2.equalTo("dormName", dormName);
  query2.equalTo("dormNum", dormNum);
  query2.equalTo("state", true);
  query3.equalTo("dormName", dormName);
  query3.equalTo("dormNum", dormNum);

  query.find({
    success: function (results) {
      // 循环处理查询到的数据
      that.setData({
        historyList: that.data.historyList.concat(results)
      })
      query1.find({
        success: function (results) {
          // 循环处理查询到的数据
          that.setData({
            historyList: that.data.historyList.concat(results)
          })
          query2.find({
            success: function (results) {
              // 循环处理查询到的数据
              that.setData({
                historyList: that.data.historyList.concat(results)
              })
              query3.find({
                success: function (results) {
                  // 循环处理查询到的数据
                  that.setData({
                    historyList: that.data.historyList.concat(results)
                  })
                  console.log(that.data.historyList.sort(compare))
                  console.log(that.data.historyList)
                },
                error: function (error) {
                  console.log("查询失败: " + error.code + " " + error.message);
                }
              });
            },
            error: function (error) {
              console.log("查询失败: " + error.code + " " + error.message);
            }
          });
        },
        error: function (error) {
          console.log("查询失败: " + error.code + " " + error.message);
        }
      });
    },
    error: function (error) {
      console.log("查询失败: " + error.code + " " + error.message);
    }
  });
}