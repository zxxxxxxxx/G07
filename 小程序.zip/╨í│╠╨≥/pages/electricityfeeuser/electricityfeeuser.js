var Bmob = require('../../utils/bmob.js');
var common = require('../../utils/common.js');
var that;

// 获取全局应用程序实例对象
var app = getApp();

// 创建页面实例对象
Page({
  /**
   * 页面名称
   */
  name: "electricityfeeuser",
  /**
   * 页面的初始数据
   */

  data: {
    user: {},
    array1: ['求真1', '求真2', '问源1', '问源2', '慕贤1', '慕贤2', '慕贤3', '弘毅1', '弘毅2', '精诚1', '精诚2', '致远1', '致远2', '尚雅1', '尚雅2', '思睿1', '思睿2', '惟学1', '明德2', '明德3'],
    index: 0,
    dormnum: 0,
    money: 0,
    loading: true,
    openId: '',
    dataInfo: [],
    PayResult: '',
    objectId: '',
  },

  pickerSelected1: function (e) {
    //改变index值，通过setData()方法重绘界面
    that = this
    that.setData({
      index: e.detail.value
    });
    var EleFee = Bmob.Object.extend("EleFee");
    var eleFee = new Bmob.Query(EleFee);
    eleFee.equalTo("dormName", that.data.array1[that.data.index]);
    eleFee.equalTo("dormNum", that.data.dormnum);
    eleFee.notEqualTo("state", true);
    eleFee.first({
      success: function (object) {
        // 查询成功
        if (object != undefined) {
          that.setData({
            money: object.get("money"),
            objectId: object.id
          })
        }
        else {
          that.setData({
            money: 0,
          })
        }
      },
      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
  },

  inputEvent: function (e) {
    that = this
    that.setData({
      dormnum: Number(e.detail.value)
    })
    var EleFee = Bmob.Object.extend("EleFee");
    var eleFee = new Bmob.Query(EleFee);
    eleFee.equalTo("dormName", that.data.array1[that.data.index]);
    eleFee.equalTo("dormNum", that.data.dormnum);
    eleFee.notEqualTo("state", true);
    eleFee.first({
      success: function (object) {
        // 查询成功
        if (object != undefined) {
          that.setData({
            money: object.get("money"),
            objectId: object.id
          })
        }
        else {
          that.setData({
            money: 0,
          })
        }
      },
      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
  },

  tap_cancel: function (e) {
    wx.navigateBack({

    })
  },

  /**
    * 生命周期函数--监听页面加载
    */
  onLoad() {
    that = this;
    var currentUser = Bmob.User.current()
    // 页面初始化 options为页面跳转所带来的参数
    that.setData({
      user: currentUser,
      index: that.data.array1.indexOf(currentUser.get("dormName")),
      dormnum: currentUser.get("dormNum"),
    })
    var EleFee = Bmob.Object.extend("EleFee");
    var eleFee = new Bmob.Query(EleFee);
    eleFee.equalTo("dormName", currentUser.get("dormName"));
    eleFee.equalTo("dormNum", currentUser.get("dormNum"));
    eleFee.notEqualTo("state", true);
    eleFee.first({
      success: function (object) {
        // 查询成功
        if (object != undefined) {
          that.setData({
            money: object.get("money"),
            objectId: object.id
          })
        }
        else {
          that.setData({
            money: 0,
          })
        }
      },
      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      },
    });

    //获取open id，请在官网填写微信小程序key
    wx.login({
      success: function (res) {
        if (res.code) {
          //发起网络请求
          console.log(res.code)

          Bmob.User.requestOpenId(res.code, {
            success: function (result) {

              that.setData({
                loading: true,
                openId: result.openid
              })
              console.log(result)
            },
            error: function (error) {
              // Show the error message somewhere
              console.log("Error: " + error.code + " " + error.message);
            }
          });
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
          common.showTip('获取用户登录态失败！', 'loading');
        }
      }
    });

  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },

  formSubmit: function (event) {
    var openId = this.data.openId;

    if (!openId) {
      console.log('未获取到openId请刷新重试');
    }

    //传参数金额，名称，描述,openid
    Bmob.Pay.wechatPay(that.data.money, '电费', '电费', openId).then(function (resp) {
      console.log('resp');
      console.log(resp);

      that.setData({
        loading: true,
        dataInfo: resp
      })

      //服务端返回成功
      var timeStamp = resp.timestamp,
        nonceStr = resp.noncestr,
        packages = resp.package,
        orderId = resp.out_trade_no,//订单号，如需保存请建表保存。
        sign = resp.sign;

      //打印订单号
      console.log(orderId);

      //发起支付
      wx.requestPayment({
        'timeStamp': timeStamp,
        'nonceStr': nonceStr,
        'package': packages,
        'signType': 'MD5',
        'paySign': sign,
        'success': function (res) {
          //付款成功,这里可以写你的业务代码
          var EleFee = Bmob.Object.extend("EleFee");
          var eleFee = new Bmob.Query(EleFee);
          eleFee.get(that.data.objectId, {
            success: function (result) {
              // 回调中可以取得这个 GameScore 对象的一个实例，然后就可以修改它了
              result.set('username', Bmob.User.current().get("username"));
              result.set('state', true);
              result.set('orderId', orderId);
              result.save();
              console.log("电费单已更新, objectId:" + result.id);
              // The object was retrieved successfully.
              wx.redirectTo({
                url: '../successful/successful',
              })
            },
            error: function (object, error) {
              console.log('电费单更新失败');
            }
          });

          console.log(res);
        },
        'fail': function (res) {
          //付款失败
          console.log('付款失败');
          console.log(res);
          // wx.redirectTo({
          //   url: '../payfailed/payfailed',
          // })
        }
      })

    }, function (err) {
      console.log('服务端返回失败');
      if (err.code == 10001) common.showTip("当前没有需要支付的电费", 'loading');
      else common.showTip(err.message, 'loading', {}, 6000);
      console.log(err);
    });
  }
})
